naive_bayes <- function(x, ...) {
    UseMethod("naive_bayes")
}
