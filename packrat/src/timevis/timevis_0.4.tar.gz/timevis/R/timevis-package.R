#' @docType package
#' @name timevis
NULL
