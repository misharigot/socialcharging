label <- gtkLabelNew()
label$setMarkup("<small>Small text</small>")
