renderer$partChanged(PangoRendererPart["underline"])
